C:\Buro\MSOffice\Office\MSACCESS.EXE q:\User\PersActif\Bud0102\CreateProvision.mdb
quit